<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
//AuthController
Route::post('register','api\AuthController@registerPhone');
Route::post('login','api\AuthController@login');
Route::post('activcodeuser','api\AuthController@activcodeuser');
Route::get('setting','api\AuthController@setting');
Route::post('contact','api\AuthController@contact');
Route::post('reset','api\AuthController@reset');
Route::post('resetPassword','api\AuthController@resetPassword');
Route::post('profileUser','api\AuthController@profileUser');
Route::post('editUser','api\AuthController@editUser');
//
Route::get('google', 'Api\SocialAuthGoogleController@redirect');
Route::get('google/callback', 'Api\SocialAuthGoogleController@callback');
//BannerController
Route::get('getBanner','api\BannerController@getBanner');

//homeController
Route::get('getCategory','api\HomeController@getCategory');
Route::get('getBrand','api\HomeController@getBrand');
Route::get('allCountry','api\HomeController@allCountry');

//Advertising Controller
Route::get('getAdv','api\AdvertisingController@getAdv');
Route::post('getCatAdv','api\AdvertisingController@getCatAdv');


Route::group(['middleware' => 'auth:api' , 'namespace'=>'api'],function(){
	//Advertising Controller
	Route::post('addAdv','AdvertisingController@addAdvertising');
	//Favourt Controller
	Route::post('addFollow','FavourtController@addFollow');
});