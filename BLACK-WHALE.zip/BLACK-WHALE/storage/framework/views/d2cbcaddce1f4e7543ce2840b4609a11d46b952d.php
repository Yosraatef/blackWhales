<?php $__env->startSection('content'); ?>
    <h3>الماركات</h3>
    <div class="col-sm-6">

        <table class="table">
            <thead>
            <tr>
                <th>الرقم</th>
                <th>القسم الرئسية</th>
                <th>القسم  الفرعي </th>
                <th> الماركة </th>
                <th>اللوجو</th>
                <th>تعديل</th>
                <th>الحدث</th>
            </tr>
            </thead>
       

            <?php if(count($brands) > 0): ?>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                    <?php $subCategory = DB::table('sub_categories')->where('id', $brand->subCategory_id)->first(); 
                   $cat = DB::table('categories')->where('id', $subCategory->category_id)->first();
                    ?>
                    <tbody>
                    <tr>
                        <td><?php echo e($loop->index +1); ?></td>
                        <td><?php echo e($cat->name); ?></td>
                        <td><?php echo e($subCategory->name); ?></td>
                        <td><?php echo e($brand->name); ?></td>
                        <td><img style="hight:120px;width:120px;margin:5px;" 
                            src="<?php echo e(asset('pictures/brands/' . $brand->image)); ?>"></td>
                        <td><a href="<?php echo e(route('detailsSubCategories.edit', $brand->id)); ?>">
                                     <button class="btn btn-outline-warning" >
                                        تعديل 
                                    </button>
                                    </a>
                        </td>
                        <td>

                            <form action="<?php echo e(route('detailsSubCategories.destroy',$brand->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>

                                <button class="btn btn-outline-danger">احذف</button>

                            </form> 
                        </td>

                    </tr>
                    </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>

        

    </div>

<?php $__env->stopSection(); ?>
 <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>

    <script>
      
 
        function showSubCategories(sel) {
            
            var id = sel.value;
            //alert(id);
            $.ajax({

                url : '/dashboard/getSubcategories/'+id,
                type:'GET',
                dataType: 'json',
                success: function(data) {

                   var len = data.data1.length;
                    $("#catstyle_sect").empty();
                    for( var i = 0; i<len; i++){
                        var id = data.data1[i]['id'];
                        var name = data.data1[i]['name'];

                        $("#catstyle_sect").append("<option value='"+id+"'>"+name+"</option>");

                    }

                  }
                });
    }
        
    </script>
   <!--  -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\BLACK-WHALE\resources\views/dashboard/detailsSubCategories/show.blade.php ENDPATH**/ ?>