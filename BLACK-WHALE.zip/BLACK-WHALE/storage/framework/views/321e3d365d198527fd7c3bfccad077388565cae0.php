<?php $__env->startSection('content'); ?>
    <h3>الفئات</h3>
    <div style="overflow-x:auto;" class="col-md-12 col-sm-6">

        <table class="table-wrapper-scroll-x my-custom-scrollbar table">
            <thead>
            <tr>
                <th>الرقم</th>
                <th>اسم صاحب الاعلان</th>
                <th>رقم  التلفون</th>
                <th>القسم الرئسية</th>
                <th>القسم  الفرعي </th>
                <th> الماركة </th>
                <th> الفئة</th>
                <th>اللوجو</th>
                <th>رقم  الإعلان</th>
                <th>اسم الاعلان</th>
                <th>وصف   الاعلان</th>
                <th>النوع</th>
                <th>موديل</th>
               <td>اللون </td>
               <td>السعر</td>
                <th>الحدث</th>
            </tr>
            </thead>
       

            <?php if(count($advertisement) > 0): ?>
                <?php $__currentLoopData = $advertisement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertising): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $catName = DB::table('categories')->where('id', $advertising->category_id)->value('name');
                $subcatName = DB::table('sub_categories')->where('id', $advertising->subCategory_id)->value('name');
                $brandName = DB::table('brands')->where('id', $advertising->brand_id)->value('name');
                $className = DB::table('classes')->where('id', $advertising->class_id)->value('name');

                ?>
                    <tbody>
                    <tr>
                        <td><?php echo e($loop->index +1); ?></td>
                        <td><?php echo e($advertising->user->name); ?></td>
                        <td><?php echo e($advertising->user->phone); ?></td>
                        <td><?php echo e($catName); ?></td>
                        <td><?php echo e($subcatName); ?></td>
                        <td><?php echo e($brandName); ?></td>
                        <td><?php echo e($className); ?></td>
                        
                        <td><img style="hight:120px;width:120px;margin:5px;" 
                            src="<?php echo e(asset('pictures/advertisement/' . $advertising->image)); ?>"></td>
                       <td><?php echo e($advertising->code_number); ?></td>
                       <td><?php echo e($advertising->title); ?></td>
                       <td><?php echo e($advertising->description); ?></td>
                       <?php if($advertising->type == 0): ?>
                       <td>مستعمل</td>
                       <?php else: ?>
                       <td>جديد </td>
                       <?php endif; ?>
                       <td><?php echo e($advertising->model); ?></td>
                       <td><?php echo e($advertising->color); ?></td>
                       <td><?php echo e($advertising->price); ?></td>
                        <td>

                            <form action="<?php echo e(route('advertising.destroy',$advertising->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>

                                <button class="btn btn-outline-danger">احذف</button>

                            </form> 
                        </td>

                    </tr>
                    </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>

        

    </div>

<?php $__env->stopSection(); ?>
 <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>

    <script>
      
 
        function showSubCategories(sel) {
            
            var id = sel.value;
            //alert(id);
            $.ajax({

                url : '/dashboard/getSubcategories/'+id,
                type:'GET',
                dataType: 'json',
                success: function(data) {

                   var len = data.data1.length;
                    $("#catstyle_sect").empty();
                    for( var i = 0; i<len; i++){
                        var id = data.data1[i]['id'];
                        var name = data.data1[i]['name'];

                        $("#catstyle_sect").append("<option value='"+id+"'>"+name+"</option>");

                    }

                  }
                });
    }
        
    </script>
   <!--  -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\BLACK-WHALE\resources\views/dashboard/advertisement/show.blade.php ENDPATH**/ ?>