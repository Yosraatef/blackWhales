<?php $__env->startSection('content'); ?>

    <section class="content">
        <div class="card" style="width: 18rem; float: right;margin: 10px;" >
            
            <div class="card-body">

                <p class="card-text">
                    <strong>
                        عدد  المستخدمين  :: <?php echo e($users); ?> مستخدم 
                    </strong>
                   
                </p>
                <a href="<?php echo e(route('users.create')); ?>"
                   class="btn btn-primary">إضافة  مستخدم  جديد </a>
            </div>
        </div>
        <div class="card" style="width: 18rem; float: right;margin: 10px;" >

            <div class="card-body">

                <p class="card-text">
                    <strong>
                        عدد  الأصناف الموجودة لدينا  :: <?php echo e($categories); ?> أصناف 
                    </strong>
                   
                </p>
                <a href="<?php echo e(route('categories.create')); ?>"
                   class="btn btn-primary">إضافة صنف جديد </a>
            </div>
        </div>
       
          <div class="card" style="width: 18rem;float: right;margin: 10px;">

            <div class="card-body">

                <p class="card-text">
                    <strong>
                        عدد  الطلبات :: طلب
                    </strong>
                    
                </p>
                <a href="#"
                   class="btn btn-primary">رؤية تفاصيل  الطلبات</a>
            </div>
        </div>
        
    </section>


        <script>
        function printDiv()
        {

            var divToPrint=document.getElementById('DivIdToPrint');

            var newWin=window.open('','Print-Window');

            newWin.document.open();

            newWin.document.write('<html lang="ar" style="text-align: right"><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');

            newWin.document.close();

            setTimeout(function(){newWin.close();},10);

        }
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\BLACK-WHALE\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>