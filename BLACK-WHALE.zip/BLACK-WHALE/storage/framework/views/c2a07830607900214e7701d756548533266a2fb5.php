<!-- Vendor js -->
<script src="<?php echo e(asset('admin/js/vendor.min.js')); ?>"></script>

<!-- knob plugin -->
<script src="<?php echo e(asset('admin/libs/jquery-knob/jquery.knob.min.js')); ?>"></script>

<!--Morris Chart-->
<script src="<?php echo e(asset('admin/libs/morris-js/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/raphael/raphael.min.js')); ?>"></script>

<!-- Dashboard init js-->
<script src="<?php echo e(asset('admin/js/pages/dashboard.init.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(asset('admin/js/app.min.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\Administrator\Desktop\BLACK-WHALE\resources\views/dashboard/footer.blade.php ENDPATH**/ ?>