<?php $__env->startSection('content'); ?>
    
<div class="col-sm-6">

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>



    <form action="<?php echo e(route('settings.store')); ?>" method="POST" >

        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">وصف التطبيق</label>
            <textarea name="aboutApp"
                      id=""
                      cols="30"
                      rows="10"
                      class="form-control">
                <?php if(array_key_exists("aboutApp",$settings_data)): ?><?php echo e($settings_data["aboutApp"]); ?><?php endif; ?>
            </textarea>
        </div>
        <div class="form-group">
            <label for="name">وصف التطبيق</label>
            <textarea name="aboutApp2"
                      id=""
                      cols="30"
                      rows="10"
                      class="form-control">
                <?php if(array_key_exists("aboutApp2",$settings_data)): ?><?php echo e($settings_data["aboutApp2"]); ?><?php endif; ?>
            </textarea>
        </div>
         <div class="form-group">
            <label for="name">وصف التطبيق</label>
            <textarea name="aboutApp3"
                      id=""
                      cols="30"
                      rows="10"
                      class="form-control">
                <?php if(array_key_exists("aboutApp3",$settings_data)): ?><?php echo e($settings_data["aboutApp3"]); ?><?php endif; ?>
            </textarea>
        </div>
         <div class="form-group">
            <label for="name">الشروط والاحكام</label>
            <textarea name="conditions"
                      id=""
                      cols="30"
                      rows="30"
                      class="form-control">
                <?php if(array_key_exists("conditions",$settings_data)): ?><?php echo e($settings_data["conditions"]); ?><?php endif; ?>
            </textarea>
        </div>
        <div class="form-group">
            <label for="name">من  نحن</label>
            <textarea name="who"
                      id=""
                      cols="30"
                      rows="10"
                      class="form-control">
                <?php if(array_key_exists("who",$settings_data)): ?><?php echo e($settings_data["who"]); ?><?php endif; ?>
            </textarea>
        </div>
        <div class="form-group">
            <input type="submit"  value="Add" class="form-control">
        </div>


    </form>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\BLACK-WHALE\resources\views/dashboard/settings/create.blade.php ENDPATH**/ ?>