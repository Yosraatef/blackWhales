<?php $__env->startSection('content'); ?>
    <h2> المستخدمين</h2>
    <div class="col-md-12 col-sm-6">
        <table class="table">
            <thead>
            <tr>
                <th>الرقم</th>
                <th> الاسم </th>
                <th> رقم  التلفون </th>
                <th>البريد الالكتروني</th>
                <th> صورة الملف الشخصي </th>
              
                <th>تعديل</th>
                <th>الحدث</th>
            </tr>
            </thead>
           
            <?php if(count($users) > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($user->type == 0): ?>
                    <tbody>
                    <tr>
                        <td><?php echo e($loop->index +1); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->phone); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><img style="hight:120px;width:120px;margin:5px;" src="<?php echo e(asset('pictures/users/' . $user->image)); ?>"></td>
                        
                        <td><a href="<?php echo e(route('users.edit', $user->id)); ?>">
                                     <button class="btn btn-outline-warning" >
                                        تعديل 
                                    </button>
                                    </a>
                        </td>
                        <td>

                            <form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>

                                <button class="btn btn-outline-danger">احذف</button>

                            </form> 
                        </td>

                    </tr>
                    </tbody>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>

        <?php echo e($users->links()); ?>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\BLACK-WHALE\resources\views/dashboard/users/show.blade.php ENDPATH**/ ?>