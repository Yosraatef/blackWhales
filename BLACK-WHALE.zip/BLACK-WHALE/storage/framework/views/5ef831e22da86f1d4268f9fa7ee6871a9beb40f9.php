<?php $__env->startSection('content'); ?>
    <h3>المناطق</h3>
    <div class="col-md-12 col-sm-6">

        <table class="table">
            <thead>
            <tr>
                <th>الرقم</th>
                <th>الدولة</th>
                <th>المدينة</th>
                <th>المنظقة </th>
                <th>تعديل</th>
                <th>الحدث</th>
            </tr>
            </thead>
           
            <?php if(count($areas) > 0): ?>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                    <tbody>
                    <tr>
                        <td><?php echo e($loop->index +1); ?></td>
                        <td><?php echo e($area->city->country->name); ?></td>
                        <td><?php echo e($area->city->name); ?></td>
                        <td><?php echo e($area->name); ?></td>
                        <td><a href="<?php echo e(route('area.edit', $area->id)); ?>">
                                     <button class="btn btn-outline-warning" >
                                        تعديل 
                                    </button>
                                    </a>
                        </td>
                        <td>

                            <form action="<?php echo e(route('area.destroy',$area->id)); ?>" method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>

                                <button class="btn btn-outline-danger">احذف</button>

                            </form> 
                        </td>

                    </tr>
                    </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>

        <?php echo e($areas->links()); ?>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\BLACK-WHALE\resources\views/dashboard/areas/show.blade.php ENDPATH**/ ?>