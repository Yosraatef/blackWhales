<?php $__env->startSection('styles'); ?>
<style type="text/css">
  .items{
    display: none;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h3>
        اضافة  مدينة</h3>
      
    </section>
    <section class="content">
            <div class="box box-primary">
              
               <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <form role="form" action="<?php echo e(route('city.store')); ?>" method="post"
              enctype="multipart/form-data">
             <?php echo e(csrf_field()); ?>


           
              <div class="box-body">
                <div class="col-lg-offset-3 col-md-6">
                  <div class="form-group">
                <label for="country_id"> الدولة  </label>
                <select id="myList" class="form-control" name="country_id" >
                     <option>اختر الخدمة التابعه لها </option>
                  <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              
                <div  id="select_others" class="form-group">
                <label for="name">اسم  المدينة  </label>
                <input type="text" name="name"
                       placeholder="ادخل  اسم  الخدمة "
                       class="form-control">
                </div>
               
            
            </div>
            
                <div class="box-footer">
                <button type="submit" class="btn btn-primary">اضافة</button>
                <a type="button" class="btn btn-warning" 
                href="<?php echo e(route('categories.index')); ?>">الرجوع</a>
              </div>
                </div>

              </div> 
            </form>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\BLACK-WHALE\resources\views/dashboard/cities/create.blade.php ENDPATH**/ ?>