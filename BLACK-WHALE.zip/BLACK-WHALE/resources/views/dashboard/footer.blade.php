<!-- Vendor js -->
<script src="{{asset('admin/js/vendor.min.js')}}"></script>

<!-- knob plugin -->
<script src="{{asset('admin/libs/jquery-knob/jquery.knob.min.js')}}"></script>

<!--Morris Chart-->
<script src="{{asset('admin/libs/morris-js/morris.min.js')}}"></script>
<script src="{{asset('admin/libs/raphael/raphael.min.js')}}"></script>

<!-- Dashboard init js-->
<script src="{{asset('admin/js/pages/dashboard.init.js')}}"></script>

<!-- App js -->
<script src="{{asset('admin/js/app.min.js')}}"></script>

@yield('scripts')
</body>
</html>