<?php

namespace App\Http\Controllers\dash;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use App\Advertising;
class AdvertisingController extends Controller
{
   
    public function index()
    {
        $advertisement = Advertising::paginate(15);
         return view('dashboard.advertisement.show',compact('advertisement'));
    }

    
    public function create()
    {
        
    }

   
    public function store(Request $request)
    {
        //
    }

   
    public function show($id)
    {
        //
    }

   
    public function edit($id)
    {
        //
    }

   
    public function update(Request $request, $id)
    {
        //
    }

  
    public function destroy($id)
    {
        $class = Advertising::findOrFail($id);

        $class->delete();
        Session::flash('message','تم  المسح بنجاح');

        return redirect()->back();
    }
}
