<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Follow;
class FavourtController extends Controller
{
   public function addFollow(Request $request){

   		$user = auth()->guard('api')->user();
   		//dd($user->id);
   		$validator= validator()->make($request->all(),[
            'following_id'     => 'required',
            ]);
            
           if($validator->fails()){
            return response()->json(['msg' =>'false','data'=>$validator->errors()]);
                                }
            $follow = new Follow;
            $follow->user_id = $user->id;
            $follow->following_id = $request->following_id;
        	$follow->save();
            return response()->json(['msg'=>'success','data'  => $follow] );

   }
}
