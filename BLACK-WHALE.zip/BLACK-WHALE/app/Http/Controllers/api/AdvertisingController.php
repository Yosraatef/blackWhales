<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Advertising;
use App\SubCategory;
class AdvertisingController extends Controller
{
    public function addAdvertising(Request $request){
    	$user = auth()->guard('api')->user();
        
          $data = $request->except('user_id','image','code_number');
          $data['user_id'] = $user->id;
          if ($request->hasFile('image')) {
            $filename = time() . '-' . $request->image->getClientOriginalName();
            $request->image->move(public_path('pictures/advertisement'), $filename);
            $data['image'] = $filename;
        }
        $data['code_number'] = rand() ;
          $advertising = Advertising::create($data);
          if ( $request->hasFile('images')) {
            foreach (request('images') as $image) {
            $images = new Image;
            $filename = time() . '-' . $image->getClientOriginalName();
            $image->move(public_path('pictures/images'), $filename);
            $images->image = $filename;

            $images->service_id = $service->id;
             $images->save();
            }
        }
          return response()->json(['msg'=>'success','data' => [
           'advertising' => $advertising,
           ]
           ] );
    }
    public function getAdv()
    {
      $arr = array();
        $advertising = Advertising::with('category')->get();
        foreach($advertising as $adv){
          //$sections = Section::where('brand_id',$brand->id)->get();
            array_push($arr, array(
                  "advertising"=> $advertising,
            ));
     }
            
           return response()->json(['msg'=>'success','data' => $arr]);
         
    }
    public function getCatAdv(Request $request)
    {
      $arr = array();
      //dd($request->subCategory_id);
        $advertising = Advertising::where(['category_id'=> $request->category_id ] )->with('category')->get();
       //dd($advertising);
        foreach($advertising as $adv){
          $subCat = SubCategory::where('id',$adv->subCategory_id)->first();
            array_push($arr, array(
                  "advertising"=> $advertising,
                  "subCategory_id" => $subCat,
            ));
     }
            
           return response()->json(['msg'=>'success','data' => $arr]);
         
    }
    
}
