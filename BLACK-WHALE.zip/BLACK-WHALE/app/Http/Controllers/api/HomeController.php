<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Country;
use App\Category;
use App\Brand;
use App\Section;
use App\SubCategory;
use App\Advertising;
class HomeController extends Controller
{
    
    public function allCountry()
    {
      $arr = array();
        $countries = Country::all();
        foreach($countries as $country){
            array_push($arr, array(
                  "id"=> $country->id,
                  "name" => $country->name,
            ));
     }
            
           return response()->json(['msg'=>'success','data' => $arr]);
         
    }

    public function getCategory()
    {
      $arr = array();
        $categories = Category::with('subCategories')->get();
        foreach($categories as $category){
        	$subCategories = SubCategory::where('category_id',$category->id)->get();
            array_push($arr, array(
                  "id"=> $category->id,
                  "name" => $category->name,
                  "image" => $category->image,
                  "subCategories" => $subCategories,
                  
            ));
     }
            
           return response()->json(['msg'=>'success','data' => $arr]);
         
    }
    public function getBrand()
    {
      $arr = array();
        $brands = Brand::all();
        foreach($brands as $brand){
        	$sections = Section::where('brand_id',$brand->id)->get();
            array_push($arr, array(
                  "id"=> $brand->id,
                  "name" => $brand->name,
                  "image" => $brand->image,
                  "sections" => $sections,
                  
            ));
     }
            
           return response()->json(['msg'=>'success','data' => $arr]);
         
    }

    

    
}
